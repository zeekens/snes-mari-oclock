All eight built-in SNES clock faces exported from the shared C++ renderer.
25 fps, 12 seconds, minute change at 6 seconds, infinite loop.
512px GIFs are nearest-neighbour enlargements of the 64px native GIFs.
Background smoothing disabled for crisp legacy scenery.
GIF palettes are limited to 256 colours; these are previews, not firmware files.
Artwork attribution: see assets/README.md in the project.
