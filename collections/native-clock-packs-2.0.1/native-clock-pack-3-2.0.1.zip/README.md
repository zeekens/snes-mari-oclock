# Pack 3 2.0.1

Extract the whole ZIP and open `previews/index.html` in a browser. Use **Next minute** to see the clock advance and trigger minute actions.

The manifest lists each local scene relative to `manifest.json`. The separate `catalog_path` is the location used by the online clock catalog.
